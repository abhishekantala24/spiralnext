import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export async function middleware(request: NextRequest) {
    const path = request.nextUrl.pathname;
    const selector = false
    
    const AppNavigators = [
        "/",
        '/about-us',
        '/home',
    ];

    const AuthNavigators = [
        "/login",
        "/signin"
    ];

    if (selector) {
        if (
            AppNavigators.includes(path) &&
            path !== "/" &&
            path !== "/about-us" &&
            path !== "/home" 
        ) {
            return NextResponse.redirect(new URL(path, request.url));
        }
        if (AuthNavigators.includes(path) && path !== "/") {
            return NextResponse.redirect(new URL("/", request.url));
        }
    } else {
        if (
            AuthNavigators.includes(path) &&
            path !== "/login"
        ) {
            return NextResponse.redirect(new URL(path, request.url));
        }
        if (AppNavigators.includes(path) && path !== "/login") {
            return NextResponse.redirect(new URL("/login", request.url));
        }
    }
}