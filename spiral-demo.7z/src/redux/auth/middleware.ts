import { createAsyncThunk } from "@reduxjs/toolkit"

import { loginWithEmailAsync, logoutActionAsync } from "./services"
// import { removeUser } from "../../services/token"
import { AxiosResponse } from "axios"
import { LoginRequestModel } from "@/types/RequestTypes"
import { LoginResponseModel } from "@/types/ResponseTypes"

// export const logoutAction = createAsyncThunk
//   <LogoutResponseModel, LogoutRequestModel
//   >("auth/logout",
//     async (request: LogoutRequestModel, { rejectWithValue, dispatch }) => {
//       removeUser()
//       dispatch(showLoader({ loading: true, message: "happening" }))
//       try {
//         const response: AxiosResponse<LogoutResponseModel> = await logoutActionAsync(request)
//         dispatch(hideLoader())
//         if (response.data.isSuccess) {
//           dispatch(
//             showMessage({
//               ...defaultMessageObj,
//               type: "success",
//               messageText: "Logout Successfully",
//             }))
//           return response?.data
//         }
//         dispatch(
//           showMessage({
//             ...defaultMessageObj,
//             type: "error",
//             messageText: "something went wrong",
//           }))
//         return rejectWithValue(response)
//       } catch (error: unknown) {
//         return rejectWithValue(error as Error)
//       }
//     }
//   )

export const loginUserByEmailAction = createAsyncThunk<
  LoginResponseModel, LoginRequestModel
>(
  "auth/loginByEmail",
  async (loginRequest: LoginRequestModel, { rejectWithValue, dispatch }) => {
    try {
      const response: any = await loginWithEmailAsync(loginRequest)
      if (response?.status === 200) {
        return response?.data
      }
      return rejectWithValue(response)
    } catch (error: unknown) {
      return rejectWithValue(error as Error)
    }
  }
)
