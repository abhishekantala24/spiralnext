'use client'
import { AxiosBasicCredentials } from "axios";
import React, { useState } from "react";
import { Col, Button, Row, Container, Card, Form } from "react-bootstrap";
import * as yup from "yup"
import { FaEye, FaEyeSlash } from "react-icons/fa"
import { useFormik } from "formik"
import TextInput from "@/component/TextInput/TextInput";
import { useAppDispatch } from "@/redux/hooks";
import { loginUserByEmailAction } from "@/redux/auth/middleware";

const initialFormData: AxiosBasicCredentials = {
  username: "",
  password: "",
}


const Login: React.FC = (): JSX.Element => {
  const dispatch = useAppDispatch()
  const [passwordToggle, setPasswordToggle] = useState(false)
  const loginCustomerIdValidation = () =>
    yup.object().shape({
      username: yup
        .string()
        .required("Please Enter username or Email Address"),
      password: yup
        .string()
        .required("Please Enter Password"),
    })

  const { handleChange, handleSubmit, handleBlur, values, touched, errors } = useFormik({
    initialValues: initialFormData,
    validationSchema: loginCustomerIdValidation,
    onSubmit: async (val: AxiosBasicCredentials) => {
      dispatch(loginUserByEmailAction({
        Email: val.username,
        password: val.password,
        browserType: "",
        BrowserVersions: ""
      }))
    },
  })


  return (
    <>
      <div style={{ backgroundColor: "#e7ffe7" }}>
        <Container>
          <Row className="vh-100 d-flex justify-content-center align-items-center">
            <Col md={8} lg={6} xs={12}>
              <div className="border border-3 border-success"></div>
              <Card className="shadow">
                <Card.Body>
                  <div className="mb-3 mt-md-4">
                    <h2 className="fw-bold mb-2 text-uppercase ">Demo Project</h2>
                    <p >Please enter your login and password!</p>
                    <div className="mb-3">
                      <Form noValidate onSubmit={handleSubmit}>
                        <TextInput
                          controlId="usernameGroup"
                          label={"Username"}
                          value={values?.username}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          touched={touched?.username}
                          errors={errors?.username}
                          formGroupClassName="mb-4 pt-3"
                          placeholder="Enter username"
                          type="text"
                          name="username"
                          maxLength={50}
                          restProps={{ "aria-describedby": "User Name" }}
                        />
                        <TextInput
                          controlId="passwordGroup"
                          label={"Password"}
                          value={values?.password}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          touched={touched?.password}
                          errors={errors?.password}
                          formGroupClassName="mb-4"
                          placeholder={"Enter Password"}
                          type={passwordToggle ? "text" : "password"}
                          name="password"
                          inputClassName="placeholder-no-fix input-password text-box single-line password"
                          restProps={{ "aria-describedby": "Password field" }}
                          rightIcon={{
                            onRightIconPress: () => {
                              setPasswordToggle(!passwordToggle)
                            },
                            toggleOff: <FaEyeSlash />,
                            toggleON: <FaEye />,
                            state: passwordToggle,
                          }}
                        />


                        <Form.Group
                          className="mb-3"
                          controlId="formBasicCheckbox"

                        >
                          <p className="small">
                            <span className="text-success">
                              Forgot password?
                            </span>
                          </p>
                        </Form.Group>
                        <div className="d-grid">
                          <Button variant="success" type="submit">
                            Login
                          </Button>
                        </div>
                      </Form>
                      <div className="mt-3">
                        <p className="mb-0  text-center">
                          Don't have an account?{" "}
                          <span className="text-success fw-bold">
                            Sign Up
                          </span>
                        </p>
                      </div>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
};

export default Login;
