'use client'
import React from 'react'
import { Card, Col, Container, Row } from 'react-bootstrap'
import styles from '../../../assets/Home.module.css';

const Home = () => {
    const cardData = [
        {
            title: 'Beautiful Sunset',
            imageSrc: 'https://picsum.photos/200/300',
            description: 'Enjoy a beautiful sunset by the beach.',
        },
        {
            title: 'Mountain Adventure',
            imageSrc: 'https://picsum.photos/seed/picsum/200/300',
            description: 'Embark on an exciting mountain adventure.',
        },
        {
            title: 'Cityscape View',
            imageSrc: 'https://picsum.photos/200/300/?blur',
            description: 'Experience the mesmerizing cityscape view.',
        },
    ];

    return (
        <div className={styles.background}>
            <Container className={`mt-5 ${styles.container}`}>
                <Row>
                    {cardData.map((card, index) => (
                        <Col key={index} md={4}>
                            <Card className={styles.card}>
                                <Card.Img
                                    variant="top"
                                    src={card.imageSrc}
                                    alt={card.title}
                                />
                                <Card.Body>
                                    <Card.Title>{card.title}</Card.Title>
                                    <Card.Text>{card.description}</Card.Text>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </Container>
        </div>
    )
}

export default Home