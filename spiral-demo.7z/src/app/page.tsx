'use client'
import React from 'react'

const Page = () => {
  return (
    <div>
      page
    </div>
  )
}

export default Page