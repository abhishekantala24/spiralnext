export const config = {
  apiURL: 'http://local-tt-react.com',
  useEncryptApplicationStorage: process.env.REACT_APP_USE_APPLICATION_ENCRYPT_STORAGE === "true",
}